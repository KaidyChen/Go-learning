# Case conversion

This package contains a single function, copied from the
`github.com/golang/protobuf/protoc-gen-go/generator` package. That
modules LICENSE is referenced in its entirety in this package.
