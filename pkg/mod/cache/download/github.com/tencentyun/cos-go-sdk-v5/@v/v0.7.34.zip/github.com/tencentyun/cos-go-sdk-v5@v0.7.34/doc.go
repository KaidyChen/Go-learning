// Package cos is COS(Cloud Object Storage) Go SDK. The V5 version(XML API).
// There are examples of using each API in the project's 'example' directory.
package cos
